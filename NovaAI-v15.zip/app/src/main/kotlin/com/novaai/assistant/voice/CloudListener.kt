package com.novaai.assistant.voice

import android.os.Handler
import android.os.Looper
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.ai.NoKeyException
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Steady mic + your AI key to turn what you say into text (used when live voice isn't available). */
class CloudListener(
    private val onText: (String) -> Unit,
    private val onHearing: (Boolean) -> Unit,
    private val onFatal: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var paused = false
    private var sm: SteadyMic? = null
    private val seg = ByteArrayOutputStream()
    private var noise = 250.0
    private var speaking = false
    private var voiced = 0
    private var quiet = 0

    fun start() {
        if (running) return
        running = true; paused = false
        val m = SteadyMic(null, { b, n -> frame(b, n) }, { msg -> main.post { onFatal(msg) } })
        sm = m
        m.start(false)
    }

    fun stop() { running = false; sm?.stop(); sm = null; onHearing(false) }
    fun pause() { paused = true; onHearing(false) }
    fun resume() { if (running) paused = false }

    private fun frame(buf: ShortArray, n: Int) {
        if (paused) { seg.reset(); speaking = false; voiced = 0; quiet = 0; return }
        var sum = 0.0
        for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
        val rms = Math.sqrt(sum / n)
        val loud = rms > maxOf(noise * 3.0, 600.0)
        if (!loud && !speaking) noise = noise * 0.9 + rms * 0.1
        if (loud) { voiced++; quiet = 0 } else if (speaking) quiet++
        if (loud || speaking) {
            val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until n) bb.putShort(buf[i])
            seg.write(bb.array())
            if (!speaking && voiced >= 2) { speaking = true; onHearing(true) }
        } else { seg.reset(); voiced = 0 }
        if (speaking && (quiet >= 8 || seg.size() > 16000 * 2 * 20)) {
            val pcm = seg.toByteArray()
            seg.reset(); speaking = false; voiced = 0; quiet = 0
            onHearing(false)
            if (pcm.size >= 16000) transcribe(pcm)
        }
    }

    private fun transcribe(pcm: ByteArray) {
        Thread {
            val text = try {
                LlmClient.transcribe(wav(pcm, 16000))
            } catch (e: NoKeyException) {
                main.post { onFatal("Settings এ AI key বসাও") }; ""
            } catch (e: Exception) { "" }
            if (text.isNotBlank()) main.post { if (running) onText(text) }
        }.start()
    }

    private fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
        h.putInt(rate); h.putInt(rate * 2); h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(pcm.size)
        return h.array() + pcm
    }
}
