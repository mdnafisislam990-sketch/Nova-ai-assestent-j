package com.novaai.assistant.ui

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaai.assistant.ai.ChatEngine
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.data.ChatMessage
import com.novaai.assistant.data.Repo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(onKeys: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs by Repo.messages.collectAsState()
    val busy by Repo.busy.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val prov = LlmClient.provider()

    LaunchedEffect(msgs.size, busy) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex) }

    fun send() {
        val t = input.trim()
        if (t.isEmpty()) return
        input = ""
        scope.launch { ChatEngine.send(ctx, t, speak = false) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Chip("🔑 " + (prov?.replaceFirstChar { it.uppercase() } ?: "API key"), onKeys)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { Repo.newChat() }) { Text("+ New", color = NovaColors.Cyan) }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (msgs.isEmpty()) {
                Text("Ask Nova anything. Bangla, English or both.", color = NovaColors.TextDim, fontSize = 14.sp)
            } else {
                LazyColumn(Modifier.fillMaxSize(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(msgs) { m -> Bubble(m) }
                    if (busy) item { Bubble(ChatMessage("…", false)) }
                }
            }
        }
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f),
                placeholder = { Text("Message Nova...") }, shape = RoundedCornerShape(24.dp), maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(46.dp).clip(CircleShape).background(NovaGrad).clickable { send() }, contentAlignment = Alignment.Center) {
                Text("➤", fontSize = 18.sp)
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
        val shape = RoundedCornerShape(16.dp)
        Box(
            Modifier.widthIn(max = 300.dp).clip(shape)
                .background(if (m.fromUser) NovaColors.Purple else NovaColors.Navy2).padding(12.dp)
        ) {
            if (m.imageUrl != null) ChatImage(m.imageUrl) else Text(m.text, fontSize = 15.sp)
        }
    }
}

@Composable
private fun ChatImage(url: String) {
    val bmp by produceState<ImageBitmap?>(null, url) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 20000; c.readTimeout = 90000
                c.inputStream.use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
            }.getOrNull()
        }
    }
    val b = bmp
    if (b == null) Text("Generating image…", color = NovaColors.TextDim)
    else Image(b, contentDescription = "Generated image", modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)))
}

@Composable
fun HistoryScreen() {
    val items by Repo.history.collectAsState()
    val fmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("History", fontSize = 22.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { Repo.clearHistory() }) { Text("Clear all", color = NovaColors.Cyan) }
        }
        if (items.isEmpty()) Text("No history yet.", color = NovaColors.TextDim, modifier = Modifier.padding(top = 24.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items) { h ->
                NovaCard(Modifier.fillMaxWidth()) {
                    Column {
                        Text(h.title, maxLines = 2)
                        Text(fmt.format(Date(h.time)), color = NovaColors.TextDim, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
