package com.novaai.assistant.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.novaai.assistant.data.Store
import com.novaai.assistant.utils.Perms

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            Store.init(ctx)
            if (Store.notif.value && Perms.overlay(ctx)) {
                NovaNotification.createChannel(ctx); NovaNotification.post(ctx)
            }
        }
    }
}
